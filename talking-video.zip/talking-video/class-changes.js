const classChanges = [
  { time: 3, target: ".changeme", add: "show" },
  { time: 9, target: ".changeme", remove: "show" },
  { time: 9, target: ".changeme", add: "hidden" },

  { time: 9, target: ".changeme2", add: "show" },
  { time: 16, target: ".changeme2", remove: "show" },
  { time: 16, target: ".changeme2", add: "hidden" },

  { time: 16, target: ".changeme3", add: "show" },
  { time: 28, target: ".changeme3", remove: "show" },
  { time: 28, target: ".changeme3", add: "hidden" }
];
